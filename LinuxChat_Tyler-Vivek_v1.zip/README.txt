How to run the server:
-Open terminal and navigate inside this LinuxChat folder
-enter in "make svr"
-execute as "./svr.out"

How to run the client:
-give the file execution permissions
-execute the file on your linux machine